# Floatee AI Final Candidate v1.1 — Android source

## Implemented
- Android Kotlin app launcher.
- Floating browser window (Android WebView / Chromium engine), shortcut buttons for Google, ChatGPT and Gemini, address/search field and back/forward navigation.
- Built-in true/false quiz page for repeatable testing.
- ML Kit Text Recognition OCR on a bitmap drawn from Floatee's own WebView.
- Optional OpenAI API analysis of OCR text. The key is entered by the user and kept only in the running service memory.
- Auto-click is deliberately restricted to the explicit `data-answer` controls on the built-in Floatee quiz page.

## Build
Open this directory in Android Studio, JDK 17, Android SDK 35; Gradle Sync; Build > Build APK(s). Debug APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Important limitations
- This is a source project, not a compiled or device-tested APK. This environment did not have Gradle installed, so build verification could not be performed here.
- OCR captures only the content drawn inside Floatee's own floating WebView. It does not read arbitrary third-party app screens. Capturing other apps requires Android MediaProjection consent and additional implementation.
- Google, ChatGPT and Gemini may restrict sign-in or features inside WebView. The sites may require opening in the official browser.
- AI requires an OpenAI API key and internet access; API usage can incur charges. Do not share the key. For production, move API calls to a secure backend.
- Automatic clicking is only enabled for the built-in test quiz controls. It is not a general-purpose clicker and does not bypass anti-overlay, anti-cheat, CAPTCHA, login, or app security protections.
- No invisible/stealth bypass is implemented. Android permission and user-visible system controls remain in force.
